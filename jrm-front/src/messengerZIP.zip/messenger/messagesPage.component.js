import React from "react";
import {} from "react-bootstrap";

/** The page which is the center for all messages for both the Commissioner
 * account type and the artist account type.
 * 
 * @returns 
 */
export default function MessagesPage(){
    
    let messagesPage;
    
    return (
        messagesPage
    )
}